// Paste your deployed Google Apps Script /exec URL here, then upload this file to GitHub.
// Leave blank to keep the existing local-only workspace.
export const APPS_SCRIPT_URL = '';
